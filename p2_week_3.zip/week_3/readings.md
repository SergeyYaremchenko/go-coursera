* https://about.sourcegraph.com/go/grpc-in-production-alan-shreve/ + * https://www.youtube.com/watch?v=7FZ6ZyzGex0
* https://grpc.io/ - общий сайт gRPC
* https://github.com/grpc/grpc-go - go-версия gRPC
* https://github.com/grpc-ecosystem - набор middleware для gRPC
* https://outcrawl.com/getting-started-microservices-go-grpc-kubernetes/
* https://improbable.io/games/blog/grpc-web-moving-past-restjson-towards-type-safe-web-apis
* https://blog.gopheracademy.com/advent-2017/go-grpc-beyond-basics/
* https://ops.tips/blog/sending-files-via-grpc/
* https://github.com/mattn/ft - file transfer via gRPC
* https://mhausenblas.info/fosdem2018-godevroom-networkingdeepdive/ - всецело полезный доклад про работу с сетью в go
* https://github.com/twitchtv/twirp - RPC-фреймворк от Twitch, достаточно молодой  
* https://blog.twitch.tv/twirp-a-sweet-new-rpc-framework-for-go-5f2febbf35f - статья про Twirp
* https://about.sourcegraph.com/go/fallacies-of-distributed-gomputing/ - мощный доклад по распределённым системам на го
* https://github.com/google/go-microservice-helpers
* https://github.com/vaporz/turbo
* https://github.com/go-kit/kit - мощный фреймворк для написания микросервисов
* https://habrahabr.ru/post/276539/ - "Это будущее". Обязательная для ознакомления статья если вы решили увлечься микросервисами по полной
* https://medium.com/apis-and-digital-transformation/openapi-and-grpc-side-by-side-b6afb08f75ed
* https://medium.com/pantomath/how-we-use-grpc-to-build-a-client-server-system-in-go-dd20045fa1c2
* https://habrahabr.ru/company/beget/blog/348008/
* https://www.ribice.ba/swagger-golang/ - Create Golang API documentation with SwaggerUI
* https://ewanvalentine.io/microservices-in-golang-part-1/ - большой туториал по микросервисам в го, охватывает множество сфер ( докер, авторизацию и прочее ) - на момент добавления в список вышла 7-я часть 
* https://github.com/MarquisIO/go-grpcmw
* https://github.com/enricofoltran/hello-auth-grpc
* https://blog.synq.fm/golang-microservice-starter-kit
* https://blog.gopheracademy.com/advent-2017/kubernetes-ready-service/
* https://www.youtube.com/watch?v=s5l9ZdgxzXA
* http://www.minaandrawos.com/2016/05/14/udp-vs-tcp-in-golang/
* http://rodaine.com/2017/05/x-files-time-rate-golang/
* https://blog.envoyproxy.io/introduction-to-modern-network-load-balancing-and-proxying-a57f6ff80236
* http://tumregels.github.io/Network-Programming-with-Go/ 

