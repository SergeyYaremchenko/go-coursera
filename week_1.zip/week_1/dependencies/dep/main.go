package main

import (
	"fmt"

	"github.com/rvasily/examplerepo"
)

func main() {
	fmt.Println(examplerepo.FirstName)
}
