package main

import (
	"io"
)

// вам надо написать более быструю оптимальную этой функции
func FastSearch(out io.Writer) {
	SlowSearch(out)
}