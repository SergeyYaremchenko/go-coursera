https://github.com/golang/dep

dep init

dep ensure

dep ensure -add github.com/foo/bar

dep status

dep ensure -update